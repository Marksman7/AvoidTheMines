﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testingexecutiveorderstiill
{
    public abstract class CommandWithUndo : Command, ICommandWithUndo
    {
        GameComponent gc;                   //Refernece to game component, ya
        public UndoCommand UndoCommand { get; set; }

        public CommandWithUndo()
        {
            //nothing
        }

        public override void Execute(GameComponent gc)
        {
            this.gc = gc;   //Hold a refernce to the game componet this command was excuted ok (connection point of classes)
            base.Execute(gc);
        }
        public void UnExecute()
        {
            this.UndoCommand.Execute(gc);
        }
    }
}
