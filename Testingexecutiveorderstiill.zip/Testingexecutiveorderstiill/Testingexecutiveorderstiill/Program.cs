﻿using System;

namespace Testingexecutiveorderstiill
{
    class Program
    {
        static void Main(string[] args)
        {
            LetsTryThisAgain TestIt = new LetsTryThisAgain();
            TestIt.SetUp();
        }
    }
}
