﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Testingexecutiveorderstiill
{
    public class MoveLeftCom : CommandWithUndo
    {
        public MoveLeftCom()
        {
            this.CommandName = "Move Left";
            this.UndoCommand = new UndoMoveLeftCommand(this);
        }

        public override void Execute(GameComponent gc)
        {
            gc.MoveLeft();
            base.Execute(gc);
        }
    }

    public class UndoMoveLeftCommand : UndoCommand
    {

        public UndoMoveLeftCommand(CommandWithUndo command) : base(command)
        {

        }

        public override void Execute(GameComponent gc)
        {
            gc.MoveRight();
            base.Execute(gc);
        }
    }
}
