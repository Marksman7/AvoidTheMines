﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Testingexecutiveorderstiill
{
    public class LetsTryThisAgain
    {
        bool playingGame = true;    //not really used

        bool OnBomb = false;

        int[,] DiscoverMap = new int[10, 10];
        int[] MapSetUp = new int[100];
        Random Randy = new Random();

        //this can run valuse throuh so ya use this mark
        public GameComponent FakeComponentReceiver { get; set; }

        //literal list that recrds things, thankfully not a node :)
        public Stack<ICommand> Commands { get; set; }

        public LetsTryThisAgain()
        {
            FakeComponentReceiver = new GameComponent();
            Commands = new Stack<ICommand>();
        }

        public void SetUp()
        {
            //puts all as zero = 0
            for (int i = 0; i < MapSetUp.Length; i++)
            {

                MapSetUp[i] = 0;
            }
            //goal to get to = 2
            MapSetUp[Randy.Next(0, 101)] = 2;
            //placeing 7 bombs = 1
            for (int q = 0; q < 7; q++)
            {

                int OrderHere = 0;

                if (MapSetUp[OrderHere] != 1 && MapSetUp[OrderHere] != 2)
                {
                    OrderHere = Randy.Next(0, 101);

                }
                
                MapSetUp[OrderHere] = 1;
            }
            //input DiscoverMap by makeing a MapSetUp
            for (int w = 0; w < 10; w++)
            {
                for (int e = 0; e < 10; e++)
                {
                    DiscoverMap[w, e] = MapSetUp[((w * 10) + e)];
                }
            }

            Run();
        }

        public void Run()
        {
            

                ConsoleKeyInfo keyI = AskForCommand();
                Command command = GetCommandFromKey(keyI);
                ProcessCommand(command);

                //Update display from coponent
                Console.WriteLine(FakeComponentReceiver.About());
            

            if (DiscoverMap[FakeComponentReceiver.GetX(), FakeComponentReceiver.GetY()] == 2)
            {
                //win event
                Console.WriteLine("You got to the goal, and hopefully not missing anything important");
            }
            else if (DiscoverMap[FakeComponentReceiver.GetX(), FakeComponentReceiver.GetY()] == 1)
            {
                //the player is on a bomb and should go back in time
                OnBomb = true;
                Run();
            }
            else
            {
                Run();
            }
        }

        public void ProcessCommand(Command command)
        {
            if (command != null)
            {
                if (command is ICommandWithUndo)
                {
                    Commands.Push((ICommandWithUndo)command); //only push commands with undo to the stack
                }
                command.Execute(FakeComponentReceiver);

            }
            else
            {
                if (DiscoverMap[FakeComponentReceiver.GetX(), FakeComponentReceiver.GetY()] == 1)
                {
                    Console.WriteLine("Your Kind of stepped on a bomb soooo...");
                }
                else
                {
                    Console.WriteLine("Either its of the plan of existance or not an actual input");
                }
                
            }

            for (int w = 9; w > -1; w--)
            {
                Console.WriteLine();

                for (int e = 0; e < 10; e++)
                {
                    if (FakeComponentReceiver.GetX() == e && FakeComponentReceiver.GetY() == w)
                    {
                        Console.Write("A ");
                    }/*
                    else if (DiscoverMap[e, w] == 1)
                    {
                        Console.Write("B ");
                    }
                    else if (DiscoverMap[e, w] == 2)
                    {
                        Console.Write("G ");
                    }*/
                    else
                    {
                        Console.Write("O ");
                    }

                    //the B is for bomb and the g is for Goal
                }
            }
        }

        private Command GetCommandFromKey(ConsoleKeyInfo keyI)
        {
            Command command = null;
            switch (keyI.Key)
            {
                case ConsoleKey.A:          //Move left
                case ConsoleKey.LeftArrow:
                    if (FakeComponentReceiver.GetX() > 0 && OnBomb == false)
                    {
                        command = new MoveLeftCom();
                    }
                    break;
                case ConsoleKey.D:          //Move right
                case ConsoleKey.RightArrow:
                    if (FakeComponentReceiver.GetX() < 9 && OnBomb == false)
                    {
                        command = new MoveRightCom();
                    }
                    break;
                case ConsoleKey.W:          //Move up
                case ConsoleKey.UpArrow:
                    if (FakeComponentReceiver.GetY() < 9 && OnBomb == false)
                    {
                        command = new MoveUpCom();
                    }
                    break;
                case ConsoleKey.S:          //Move down
                case ConsoleKey.DownArrow:
                    if (FakeComponentReceiver.GetY() > 0 && OnBomb == false)
                    {
                        command = new MoveDownCom();
                    }
                    break;
                case ConsoleKey.Escape:     //Exit game
                case ConsoleKey.Q:
                    playingGame = false;
                    break;
                case ConsoleKey.Z:  //undo
                    if (Commands.Count > 0)
                    {
                        command = (Command)Commands.Pop();
                        if (command is ICommandWithUndo) //if the popped command has an undo command use it
                        {
                            command = ((ICommandWithUndo)command).UndoCommand;
                        }
                        OnBomb = false;
                    }
                    break;
            }
            return command;
        }

        private ConsoleKeyInfo AskForCommand()
        {
            Console.Write(string.Format("Command Stack Size {0} \tPlease enter a key:", Commands.Count.ToString()));
            ConsoleKeyInfo ki = Console.ReadKey();
            Console.WriteLine(""); //new line
            return ki;
        }
    }
}