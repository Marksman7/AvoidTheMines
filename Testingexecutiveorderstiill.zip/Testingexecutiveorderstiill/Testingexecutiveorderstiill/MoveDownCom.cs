﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Testingexecutiveorderstiill
{
    public class MoveDownCom : CommandWithUndo
    {
        public MoveDownCom()
        {
            this.CommandName = "Move Up";
            this.UndoCommand = new UndoMoveDownCommand(this);
        }

        public override void Execute(GameComponent gc)
        {
            gc.MoveDown();
            base.Execute(gc);
        }
    }

    public class UndoMoveDownCommand : UndoCommand
    {

        public UndoMoveDownCommand(CommandWithUndo command) : base(command)
        {

        }

        public override void Execute(GameComponent gc)
        {
            gc.MoveUp();
            base.Execute(gc);
        }
    }
}
