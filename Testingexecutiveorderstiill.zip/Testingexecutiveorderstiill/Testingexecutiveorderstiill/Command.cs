﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testingexecutiveorderstiill
{
    public abstract class Command : ICommand
    {
        public string CommandName;       //Name For logging, OK

        public Command()
        {

        }

        public virtual void Execute(GameComponent gc)
        {
            this.Log();     //Log that command happened; stuff does happen
        }

        protected virtual void Log()
        {
            Console.WriteLine(string.Format("{0} executed.", CommandName));
        }
    }
}
